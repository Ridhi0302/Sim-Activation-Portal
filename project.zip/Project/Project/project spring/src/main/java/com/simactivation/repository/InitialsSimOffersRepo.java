package com.simactivation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.simactivation.entity.SimOffers;

public interface InitialsSimOffersRepo extends JpaRepository<SimOffers, Integer>{

}
